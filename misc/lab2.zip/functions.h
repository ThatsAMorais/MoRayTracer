// **************************************************************************
// file: 	functions.h
// author: 	Alex Morais
// purpose: To provide some general global functions to support ray tracer
// **************************************************************************

#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <gm.h>

gmVector3 FourToThree(gmVector4* vec4){
	gmVector3 vec3;

	vec3[0] = (*vec4)[0];
	vec3[1] = (*vec4)[1];
	vec3[2] = (*vec4)[2];

	return vec3;
}

gmVector4 ThreeToFour(gmVector3* vec3){
	gmVector4 vec4;

	vec4[0] = (*vec3)[0];
	vec4[1] = (*vec3)[1];
	vec4[2] = (*vec3)[2];
	vec4[3] = 1.0;

	return vec4;
}

extern bool testPixel;

#endif
