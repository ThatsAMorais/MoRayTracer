/////////Lab 1 Readme:////////////

Execution Instructions:
	
	>> make
	>> cat <file.ray> | ./mray.exe > outfile.ppm
	>> convert -flip outfile.ppm output.png
	>> eog output.png			# here you could use the image viewer of your choice

...and that should do it.

Ray/Image files:
	- assignment_2.ray / assignment_2.png
	- pyramid.ray / pyramid.png
	- mirror.ray / daves_mirrors.png
	- triforce.ray ( incomplete : no image rendered )

The included images are from these three files and are named respectively.
//////////////////////////////////
